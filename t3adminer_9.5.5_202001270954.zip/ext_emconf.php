<?php

/***************************************************************
 * Extension Manager/Repository config file for ext "t3adminer".
 *
 * Auto generated 12-03-2019 14:53
 *
 * Manual updates:
 * Only the data in the array - everything else is removed by next
 * writing. "version" and "dependencies" must not be touched!
 ***************************************************************/

$EM_CONF[$_EXTKEY] = array (
  'title' => 'Adminer',
  'description' => 'Database administration tool \'Adminer\' (fork for SdbAdminer)',
  'category' => 'module',
  'author' => 'Jigal van Hemert',
  'author_email' => 'jigal.van.hemert@typo3.org',
  'author_company' => '',
  'state' => 'stable',
  'uploadfolder' => false,
  'createDirs' => '',
  'clearCacheOnLoad' => 0,
  'version' => '9.5.5',
  'constraints' => 
  array (
    'depends' => 
    array (
      'typo3' => '9.5.0-9.5.999',
      'php' => '7.2.0-7.2.999',
    ),
    'conflicts' => 
    array (
    ),
    'suggests' => 
    array (
    ),
  ),
  'clearcacheonload' => false,
);

