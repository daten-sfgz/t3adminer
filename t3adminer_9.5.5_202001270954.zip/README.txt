
T3Adminer integrates the Adminer database admin tool as a module for TYPO3. The module doesn't need configuration (there are a few optional settings).
- all DBMS supported by DBAL are supported and automatically detected
- styling matches the TYPO3 backend
- languages supported by Adminer are automatically selected
